import dotenv from "dotenv";
dotenv.config();

import express from "express";
import http from "http";
import mongoose from "mongoose";
import { Server } from "socket.io";
import Board from "./models/Board.js";

console.log("MONGO_URI =", process.env.MONGO_URI);

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*"
  }
});

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected");

    server.listen(4000, () => {
      console.log("Server running on port 4000");
    });
  })
  .catch(err => {
    console.error("Mongo connection error:", err.message);
    process.exit(1);
  });

io.on("connection", socket => {
  socket.on("joinBoard", async boardId => {
    socket.join(boardId);
    const board = await Board.findOne({ boardId }).lean();
    if (board) socket.emit("boardState", board);
  });

  socket.on("cardDrag", async ({ boardId, source, destination, draggableId }) => {
    if (!destination) return;

    const board = await Board.findOne({ boardId });
    if (!board) return;

    const startCol = board.columns.get(source.droppableId);
    const endCol = board.columns.get(destination.droppableId);

    if (startCol.id === endCol.id) {
      const newTaskIds = [...startCol.taskIds];
      newTaskIds.splice(source.index, 1);
      newTaskIds.splice(destination.index, 0, draggableId);
      startCol.taskIds = newTaskIds;
      board.columns.set(startCol.id, startCol);
    } else {
      const startIds = [...startCol.taskIds];
      startIds.splice(source.index, 1);
      startCol.taskIds = startIds;

      const endIds = [...endCol.taskIds];
      endIds.splice(destination.index, 0, draggableId);
      endCol.taskIds = endIds;

      board.columns.set(startCol.id, startCol);
      board.columns.set(endCol.id, endCol);
    }

    await board.save();
    io.to(boardId).emit("boardUpdate", board.toObject());
  });
});
