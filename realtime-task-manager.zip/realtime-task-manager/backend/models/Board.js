import mongoose from "mongoose";

const TaskSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },
    content: { type: String, required: true }
  },
  { _id: false }
);

const ColumnSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },
    title: { type: String, required: true },
    taskIds: { type: [String], required: true }
  },
  { _id: false }
);

const BoardSchema = new mongoose.Schema(
  {
    boardId: { type: String, required: true, unique: true },
    tasks: {
      type: Map,
      of: TaskSchema,
      required: true
    },
    columns: {
      type: Map,
      of: ColumnSchema,
      required: true
    },
    columnOrder: {
      type: [String],
      required: true
    }
  },
  { timestamps: true }
);

export default mongoose.model("Board", BoardSchema);
