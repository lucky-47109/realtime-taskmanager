import ReactDOM from "react-dom/client";
import Board from "./components/Board.jsx";
import "./index.css";

const root = document.getElementById("root");

ReactDOM.createRoot(root).render(
  <Board boardId="board-1" />
);
