import { useEffect, useState } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import io from "socket.io-client";

const socket = io("http://localhost:4000");

export default function Board({ boardId }) {
  const [board, setBoard] = useState(null);

  useEffect(() => {
    socket.emit("joinBoard", boardId);

    socket.on("boardState", data => setBoard(data));
    socket.on("boardUpdate", data => setBoard(data));

    return () => {
      socket.off("boardState");
      socket.off("boardUpdate");
    };
  }, [boardId]);

  if (!board) {
    return <div className="p-4">Loading…</div>;
  }

  const onDragEnd = result => {
    const { source, destination, draggableId } = result;
    if (!destination) return;

    const newBoard = structuredClone(board);

    const startCol = newBoard.columns[source.droppableId];
    const endCol = newBoard.columns[destination.droppableId];

    if (startCol.id === endCol.id) {
      const ids = Array.from(startCol.taskIds);
      ids.splice(source.index, 1);
      ids.splice(destination.index, 0, draggableId);
      startCol.taskIds = ids;
    } else {
      const startIds = Array.from(startCol.taskIds);
      startIds.splice(source.index, 1);
      startCol.taskIds = startIds;

      const endIds = Array.from(endCol.taskIds);
      endIds.splice(destination.index, 0, draggableId);
      endCol.taskIds = endIds;
    }

    setBoard(newBoard);

    socket.emit("cardDrag", {
      boardId,
      source,
      destination,
      draggableId
    });
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-4 p-4">
        {board.columnOrder.map(colId => {
          const column = board.columns[colId];
          return (
            <Droppable droppableId={column.id} key={column.id}>
              {prov => (
                <div
                  ref={prov.innerRef}
                  {...prov.droppableProps}
                  className="bg-gray-100 p-3 w-64 rounded"
                >
                  <h3 className="font-bold mb-2">{column.title}</h3>

                  {column.taskIds.map((taskId, index) => {
                    const task = board.tasks[taskId];
                    return (
                      <Draggable
                        draggableId={task.id}
                        index={index}
                        key={task.id}
                      >
                        {prov => (
                          <div
                            ref={prov.innerRef}
                            {...prov.draggableProps}
                            {...prov.dragHandleProps}
                            className="bg-white p-2 mb-2 rounded shadow"
                          >
                            {task.content}
                          </div>
                        )}
                      </Draggable>
                    );
                  })}

                  {prov.placeholder}
                </div>
              )}
            </Droppable>
          );
        })}
      </div>
    </DragDropContext>
  );
}
